<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Models\Theme;

class ThemeServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        // Partager le thème actuel avec toutes les vues
        view()->composer('*', function ($view) {
            $theme = Theme::getCurrentTheme();
            $view->with('currentTheme', $theme);
        });

        // Ajouter les variables CSS du thème
        view()->composer('*', function ($view) {
            $theme = Theme::getCurrentTheme();
            
            $cssVariables = [
                '--primary-color' => $theme->couleur_principale ?? '#b15d15',
                '--primary-dark' => $this->darkenColor($theme->couleur_principale ?? '#b15d15', 20),
                '--primary-light' => $this->lightenColor($theme->couleur_principale ?? '#b15d15', 20),
                '--secondary-color' => $theme->couleur_secondaire ?? '#000000',
                '--primary-gradient' => 'linear-gradient(135deg, ' . 
                    ($theme->couleur_secondaire ?? '#000000') . ', ' . 
                    ($theme->couleur_principale ?? '#b15d15') . ')',
                '--theme-name' => $theme->nom ?? 'Default'
            ];

            $view->with('themeCss', $cssVariables);
        });
    }

    /**
     * Fonction pour assombrir une couleur
     */
    private function darkenColor($color, $percent)
    {
        $color = ltrim($color, '#');
        if (strlen($color) == 3) {
            $color = $color[0].$color[0].$color[1].$color[1].$color[2].$color[2];
        }
        
        list($r, $g, $b) = array_map('hexdec', str_split($color, 2));
        
        $r = max(0, min(255, $r - ($r * $percent / 100)));
        $g = max(0, min(255, $g - ($g * $percent / 100)));
        $b = max(0, min(255, $b - ($b * $percent / 100)));
        
        return sprintf("#%02x%02x%02x", $r, $g, $b);
    }

    /**
     * Fonction pour éclaircir une couleur
     */
    private function lightenColor($color, $percent)
    {
        $color = ltrim($color, '#');
        if (strlen($color) == 3) {
            $color = $color[0].$color[0].$color[1].$color[1].$color[2].$color[2];
        }
        
        list($r, $g, $b) = array_map('hexdec', str_split($color, 2));
        
        $r = max(0, min(255, $r + ((255 - $r) * $percent / 100)));
        $g = max(0, min(255, $g + ((255 - $g) * $percent / 100)));
        $b = max(0, min(255, $b + ((255 - $b) * $percent / 100)));
        
        return sprintf("#%02x%02x%02x", $r, $g, $b);
    }
}